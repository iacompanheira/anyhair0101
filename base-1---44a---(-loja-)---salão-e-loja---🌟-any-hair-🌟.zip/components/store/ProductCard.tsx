import React from 'react';
import type { Product } from '../../types';
import { useAppContext } from '../../contexts/AppContext';
import { formatCurrency } from '../../utils/formatters';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { branding } = useAppContext();

  const titleStyle: React.CSSProperties = {
    fontSize: `${branding.layout.cardTitle.fontSize}px`,
    fontWeight: branding.layout.cardTitle.fontWeight as React.CSSProperties['fontWeight'],
  };
  const bodyStyle: React.CSSProperties = {
    fontSize: `${branding.layout.cardBody.fontSize}px`,
    fontWeight: branding.layout.cardBody.fontWeight as React.CSSProperties['fontWeight'],
  };
  const priceStyle: React.CSSProperties = {
    fontSize: `${branding.layout.cardPrice.fontSize}px`,
    fontWeight: branding.layout.cardPrice.fontWeight as React.CSSProperties['fontWeight'],
  };

  return (
    <div className={`bg-white rounded-layout overflow-hidden flex flex-col group transform hover:-translate-y-2 transition-transform duration-300 ease-in-out ${branding.layout.cardShadow}`}>
      <div className="relative aspect-square overflow-hidden">
        <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-brand-primary mb-2" style={titleStyle}>
            {product.name}
        </h3>
        <p className="text-gray-600 mb-4 flex-grow" style={bodyStyle}>{product.description}</p>
        <div className="mt-auto" style={priceStyle}>
            {product.promotionalPrice && product.promotionalPrice < product.price ? (
                <div className="flex items-baseline gap-2">
                    <span className="text-xl font-bold text-brand-primary">{formatCurrency(product.promotionalPrice)}</span>
                    <span className="text-base text-gray-400 line-through">{formatCurrency(product.price)}</span>
                </div>
            ) : (
                <span className="text-xl font-bold text-brand-dark">{formatCurrency(product.price)}</span>
            )}
        </div>
      </div>
       <button onClick={() => alert(`Adicionando ${product.name} ao carrinho!`)} className="w-full bg-brand-primary text-white font-sans py-3 px-4 border-2 border-transparent hover:bg-white hover:text-brand-primary hover:border-brand-primary transition-all duration-300 ease-in-out btn-text-layout">
          Adicionar ao Carrinho
        </button>
    </div>
  );
};

export default ProductCard;