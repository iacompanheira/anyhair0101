import React, { useState, useEffect, useMemo } from 'react';
import { useAppContext } from '../../contexts/AppContext';
import type { Product, Branding, FontStyleControl } from '../../types';
import { formatCurrency } from '../../utils/formatters';
import { ToggleSwitch } from '../../components/ui/ToggleSwitch';
import { Button } from '../../components/ui/Button';
import { HelpTooltip } from '../../components/ui/HelpTooltip';

// --- ICONS ---
const PlusCircleIcon: React.FC<{ className?: string }> = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${className ?? ''}`} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" clipRule="evenodd" /></svg>;
const PencilIcon: React.FC<{ className?: string }> = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${className ?? 'text-blue-500'}`} viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" /></svg>;
const TrashIcon: React.FC<{ className?: string }> = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${className ?? 'text-red-500'}`} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" /></svg>;
const AlertIcon: React.FC<{className?: string}> = ({className}) => <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${className}`} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M8.257 3.099c.636-1.21 2.85-1.21 3.486 0l5.58 10.622c.636 1.21-.462 2.779-1.743 2.779H4.42c-1.281 0-2.379-1.569-1.743-2.779L8.257 3.099zM10 13a1 1 0 11-2 0 1 1 0 012 0zm-1-3a1 1 0 00-1 1v2a1 1 0 102 0v-2a1 1 0 00-1-1z" clipRule="evenodd" /></svg>;
const SpinnerIcon: React.FC<{className?: string}> = ({className}) => <svg className={`animate-spin ${className ?? ''}`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>;
const ChevronDownIcon: React.FC<{ className?: string }> = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 transition-transform ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7 7" /></svg>;

const FONT_WEIGHTS = [ { value: '300', label: 'Leve (300)'}, { value: '400', label: 'Normal (400)'}, { value: '500', label: 'Médio (500)'}, { value: '600', label: 'Semi-negrito (600)'}, { value: '700', label: 'Negrito (700)'}, { value: '800', label: 'Extra-negrito (800)'}, { value: '900', label: 'Preto (900)'}, ];

const AccordionItem: React.FC<{ title: string; children: React.ReactNode; isOpen: boolean; onToggle: () => void; }> = ({ title, children, isOpen, onToggle }) => (
    <div className="bg-white rounded-xl shadow-md border overflow-hidden">
        <button onClick={onToggle} className="w-full flex justify-between items-center p-6 text-left">
            <h3 className="text-xl font-bold text-brand-dark">{title}</h3>
            <ChevronDownIcon className={isOpen ? 'rotate-180' : ''} />
        </button>
        {isOpen && (
            <div className="p-6 pt-0 animate-fade-in-down">
                {children}
            </div>
        )}
    </div>
);

const ColorInput: React.FC<{ label: string; value: string; onChange: (value: string) => void; }> = ({ label, value, onChange }) => (
    <div className="p-4 rounded-lg border-2 bg-gray-50">
        <div className="flex justify-between items-center">
            <label className="font-semibold text-gray-800">{label}</label>
            <div className="flex items-center gap-2 border border-gray-300 bg-white rounded-lg px-2">
                <input type="color" value={value} onChange={e => onChange(e.target.value)} className="w-7 h-7 bg-transparent border-none cursor-pointer" />
                <input type="text" value={value} onChange={e => onChange(e.target.value)} className="font-mono text-sm p-1 w-20 outline-none" />
            </div>
        </div>
    </div>
);

const FontStyleEditor: React.FC<{ label: string, style: FontStyleControl, onStyleChange: (field: keyof FontStyleControl, value: any) => void }> = ({ label, style, onStyleChange }) => {
    return (
        <div className="p-4 rounded-lg border bg-gray-50">
            <label className="block text-sm font-semibold text-gray-700 mb-2">{label}</label>
            <div className="space-y-4">
                <div>
                    <label className="text-xs text-gray-600">Tamanho da Fonte</label>
                    <div className="flex items-center gap-2">
                        <input type="range" min="10" max="72" value={style.fontSize} onChange={e => onStyleChange('fontSize', Number(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-brand-primary" />
                        <span className="font-mono text-sm bg-white border rounded-md px-2 py-1 text-center text-gray-800 w-14">{style.fontSize}px</span>
                    </div>
                </div>
                <div>
                    <label className="text-xs text-gray-600">Peso da Fonte</label>
                    <select value={style.fontWeight} onChange={e => onStyleChange('fontWeight', e.target.value)} className="select-dark text-sm w-full mt-1">
                        {FONT_WEIGHTS.map(w => <option key={w.value} value={w.value}>{w.label}</option>)}
                    </select>
                </div>
                 <div>
                     <label className="text-xs text-gray-600">Estilo da Fonte</label>
                     <div className="flex items-center gap-2 mt-1">
                        <button type="button" onClick={() => onStyleChange('fontStyle', 'normal')} className={`px-3 py-1.5 rounded-md border text-sm font-semibold transition-colors flex-1 ${style.fontStyle === 'normal' ? 'bg-brand-primary text-white border-brand-primary' : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-100'}`}>Normal</button>
                         <button type="button" onClick={() => onStyleChange('fontStyle', 'italic')} className={`px-3 py-1.5 rounded-md border text-sm italic transition-colors flex-1 ${style.fontStyle === 'italic' ? 'bg-brand-primary text-white border-brand-primary' : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-100'}`}>Itálico</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

// --- MODALS ---
const ConfirmationModal: React.FC<{ isOpen: boolean; onClose: () => void; onConfirm: () => void; title: string; children: React.ReactNode; }> = ({ isOpen, onClose, onConfirm, title, children }) => {
    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-[60] p-4" onClick={onClose}>
            <div className="bg-white w-full max-w-md rounded-xl shadow-xl text-brand-dark flex flex-col" onClick={e => e.stopPropagation()}>
                <header className="p-5 border-b"><h3 className="font-bold text-lg">{title}</h3></header>
                <main className="p-5 text-gray-600">{children}</main>
                <footer className="p-4 bg-gray-50 flex justify-end gap-3 rounded-b-xl">
                    <button onClick={onClose} className="btn-secondary">Cancelar</button>
                    <button onClick={onConfirm} className="btn-danger">Excluir Produto</button>
                </footer>
            </div>
        </div>
    );
};

const ProductModal: React.FC<{ isOpen: boolean; onClose: () => void; onSave: (product: Omit<Product, 'id'>) => void; productToEdit: Product | null; }> = ({ isOpen, onClose, onSave, productToEdit }) => {
    const [draft, setDraft] = useState<Omit<Product, 'id'>>({ name: '', description: '', price: 0, promotionalPrice: undefined, imageUrl: '', stock: 0, minimumStock: 0, isBestseller: false, isNew: false, isFeatured: false });

    useEffect(() => {
        if (isOpen) {
            setDraft(productToEdit || { name: '', description: '', price: 0, promotionalPrice: undefined, imageUrl: '', stock: 0, minimumStock: 0, isBestseller: false, isNew: false, isFeatured: false });
        }
    }, [productToEdit, isOpen]);

    if (!isOpen) return null;

    const handleChange = (field: keyof typeof draft, value: any) => {
        setDraft(prev => ({ ...prev, [field]: value }));
    };
    
    const handleNumberChange = (field