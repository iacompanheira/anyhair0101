import React from 'react';

const ServicesScreen = () => {
    return (
        <div>
            This file is no longer used for service management. 
            The service management panel has been moved from BrandingScreen to FinancialScreen as per the user's request
            to centralize service and combo creation within the financial analysis workflow.
        </div>
    );
}

export default ServicesScreen;
